Bug 1
If the user is not connected , his messages should not be accpped. Right now his messages are appended to the screen.

