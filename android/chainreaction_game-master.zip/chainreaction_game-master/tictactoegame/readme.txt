This game works only on terminal(ubuntu,linux) utility.
Based on peer to peer multiplayer game.only two player can play at a time.
first one of them can create game and other one can join after that.
There are some extra features to make game friendly.
Code is well commented and user friendly to easily accessable.
Instructions:-
			P		For pausing the Game
			Q		For Quiting the Game instantly
			R		For Resuming the Game
			@		Include to send a Message